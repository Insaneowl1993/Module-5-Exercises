const friends = [
    { id: 1, name: 'Phoebe', gender: 'female', letter: 'P'},
    { id: 2, name: 'Joey', gender: 'male', letter: 'J'},
    { id: 3, name: 'Chandler', gender: 'male', letter: 'C'},
    { id: 4, name: 'Monica', gender: 'female', letter: 'M'},
    { id: 5, name: 'Ross', gender: 'male', letter: 'R'},
    { id: 6, name: 'Rachael', gender: 'female', letter: 'R'}
]

module.exports = friends;